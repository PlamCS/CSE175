#
# vars.py
#
# This file contains global variables for route-finding search.
#
# David Noelle - Tue Sep 26 14:58:56 PDT 2023
#

# Number of nodes expanded during a search ...
node_expansion_count = 0
